var classsates_1_1core_1_1doc__list =
[
    [ "add", "classsates_1_1core_1_1doc__list.html#a8d833448ae3dda81fd642795b0b85584", null ],
    [ "remove", "classsates_1_1core_1_1doc__list.html#a1ab1d174eb03df9c77df328536526382", null ],
    [ "remove", "classsates_1_1core_1_1doc__list.html#a78794efa7921b6d7e2144fc70d2ec5b8", null ],
    [ "get", "classsates_1_1core_1_1doc__list.html#a6e9f77a6254c5aff9f8f5723663ac8ce", null ],
    [ "get_list", "classsates_1_1core_1_1doc__list.html#ae87482e53ff587e76641ceee0bd83c77", null ],
    [ "cross_ref_gen", "classsates_1_1core_1_1doc__list.html#a2d91bff06a4b61a2de9f5e1a58d2343e", null ]
];