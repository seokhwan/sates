var group__algorithm =
[
    [ "fmea_critical_number", "classsates_1_1algorithm_1_1fmea__critical__number.html", [
      [ "fmea_critical_number", "classsates_1_1algorithm_1_1fmea__critical__number.html#a7e890539e2da3a221fb8a6d81e8a32d9", null ],
      [ "gen", "classsates_1_1algorithm_1_1fmea__critical__number.html#ac6e93429075750f0fd93e1b63b9ba5ec", null ]
    ] ],
    [ "fmea_rpn", "classsates_1_1algorithm_1_1fmea__rpn.html", [
      [ "fmea_rpn", "classsates_1_1algorithm_1_1fmea__rpn.html#aca2c6871cb561d89748a14358a64b458", null ],
      [ "gen", "classsates_1_1algorithm_1_1fmea__rpn.html#a16b524bff3507f59e59a17cfd93b31a1", null ]
    ] ],
    [ "fmea_sod", "classsates_1_1algorithm_1_1fmea__sod.html", [
      [ "fmea_sod", "classsates_1_1algorithm_1_1fmea__sod.html#adcd2e3c44a75ad991dd82e659dbf6dc9", null ],
      [ "gen", "classsates_1_1algorithm_1_1fmea__sod.html#a0109495539bb2e87561285505bdd6ceb", null ]
    ] ],
    [ "infogen", "classsates_1_1algorithm_1_1infogen.html", [
      [ "gen", "classsates_1_1algorithm_1_1infogen.html#a418898aad5bdb78a6a798b3613f34777", null ],
      [ "doc_type", "classsates_1_1algorithm_1_1infogen.html#a700a4fbe5a169c10bd72f92a7baddeac", null ],
      [ "info_name", "classsates_1_1algorithm_1_1infogen.html#a943fbc6d9470f8eb7340c540f204d243", null ]
    ] ],
    [ "infogen_manager", "classsates_1_1algorithm_1_1infogen__manager.html", [
      [ "create", "classsates_1_1algorithm_1_1infogen__manager.html#a3ae2a9ce4322581fded91591fbb7b838", null ],
      [ "register_or_replace_infogen", "classsates_1_1algorithm_1_1infogen__manager.html#a0282ba118914d2eeead7a5c0b5f8f8c4", null ],
      [ "run", "classsates_1_1algorithm_1_1infogen__manager.html#a6560a915076a61590777d501ece60574", null ]
    ] ]
];