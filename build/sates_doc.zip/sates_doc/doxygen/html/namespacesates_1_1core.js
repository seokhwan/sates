var namespacesates_1_1core =
[
    [ "setter", "namespacesates_1_1core_1_1setter.html", "namespacesates_1_1core_1_1setter" ],
    [ "doc", "classsates_1_1core_1_1doc.html", "classsates_1_1core_1_1doc" ],
    [ "doc_factory", "classsates_1_1core_1_1doc__factory.html", "classsates_1_1core_1_1doc__factory" ],
    [ "doc_list", "classsates_1_1core_1_1doc__list.html", "classsates_1_1core_1_1doc__list" ],
    [ "doc_spec", "classsates_1_1core_1_1doc__spec.html", "classsates_1_1core_1_1doc__spec" ],
    [ "info", "classsates_1_1core_1_1info.html", "classsates_1_1core_1_1info" ],
    [ "os_setting", "classsates_1_1core_1_1os__setting.html", "classsates_1_1core_1_1os__setting" ]
];