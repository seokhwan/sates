var classsates_1_1util_1_1file__transfer =
[
    [ "receive", "classsates_1_1util_1_1file__transfer.html#a25a35dc5989b6d185ec29f5c053f587f", null ],
    [ "send", "classsates_1_1util_1_1file__transfer.html#a00768963d353a656d2069d99ca1fa079", null ]
];