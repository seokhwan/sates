var group___r02___f_u_n_c_t_i_o_n_a_l =
[
    [ "RF_0100_ADD_DOC", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0100___a_d_d___d_o_c.html", null ],
    [ "RF_0101_ADD_DOC_BY_TEXT_FILE", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0101___a_d_d___d_o_c___b_y___t_e_x_t___f_i_l_e.html", null ],
    [ "RF_0102_ADD_DOC_VIA_NET", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0102___a_d_d___d_o_c___v_i_a___n_e_t.html", null ],
    [ "RF_0103_READ_SATES_DOC", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0103___r_e_a_d___s_a_t_e_s___d_o_c.html", null ],
    [ "RF_0400_SKIP_SEG_FAULT", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0400___s_k_i_p___s_e_g___f_a_u_l_t.html", null ],
    [ "RF_0500_DOC_GEN", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0500___d_o_c___g_e_n.html", null ],
    [ "RF_0600_SPEC_CHANGE_COST", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0600___s_p_e_c___c_h_a_n_g_e___c_o_s_t.html", null ]
];