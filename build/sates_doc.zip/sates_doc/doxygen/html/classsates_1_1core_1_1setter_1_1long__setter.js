var classsates_1_1core_1_1setter_1_1long__setter =
[
    [ "set", "classsates_1_1core_1_1setter_1_1long__setter.html#a290cfb2fbb5fbf557181e111d845fc9e", null ]
];