var group__util =
[
    [ "file_transfer", "classsates_1_1util_1_1file__transfer.html", [
      [ "receive", "classsates_1_1util_1_1file__transfer.html#a25a35dc5989b6d185ec29f5c053f587f", null ],
      [ "send", "classsates_1_1util_1_1file__transfer.html#a00768963d353a656d2069d99ca1fa079", null ]
    ] ],
    [ "string_transfer", "classsates_1_1util_1_1string__transfer.html", [
      [ "receive", "group__util.html#ga937918c51b42965f3b39813b073a6963", null ],
      [ "send", "group__util.html#ga13b7f7db5f766110f3710bd8732d7a66", null ]
    ] ]
];