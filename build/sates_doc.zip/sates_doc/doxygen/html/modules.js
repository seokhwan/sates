var modules =
[
    [ "CODE", "group___c_o_d_e.html", "group___c_o_d_e" ],
    [ "DOC", "group___d_o_c.html", "group___d_o_c" ]
];