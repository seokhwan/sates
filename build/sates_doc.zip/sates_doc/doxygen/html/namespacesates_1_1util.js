var namespacesates_1_1util =
[
    [ "file_transfer", "classsates_1_1util_1_1file__transfer.html", "classsates_1_1util_1_1file__transfer" ],
    [ "string_transfer", "classsates_1_1util_1_1string__transfer.html", "classsates_1_1util_1_1string__transfer" ]
];