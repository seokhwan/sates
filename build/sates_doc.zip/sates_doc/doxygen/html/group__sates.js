var group__sates =
[
    [ "algorithm", "group__algorithm.html", "group__algorithm" ],
    [ "core", "group__core.html", "group__core" ],
    [ "input", "group__input.html", "group__input" ],
    [ "output", "group__output.html", "group__output" ],
    [ "test", "group__test.html", "group__test" ],
    [ "util", "group__util.html", "group__util" ]
];