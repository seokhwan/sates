var classsates_1_1core_1_1doc__factory =
[
    [ "create", "classsates_1_1core_1_1doc__factory.html#a09d31b0b22b279f84c3dacd7604d5a0a", null ]
];