var classsates_1_1input_1_1api_1_1doc__add =
[
    [ "set", "classsates_1_1input_1_1api_1_1doc__add.html#a21a33418784e03bda6551e476ba79938", null ],
    [ "call", "classsates_1_1input_1_1api_1_1doc__add.html#a92b55ea5cbab797f7e1702f5440ba45b", null ]
];