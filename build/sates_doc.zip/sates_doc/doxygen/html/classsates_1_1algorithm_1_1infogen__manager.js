var classsates_1_1algorithm_1_1infogen__manager =
[
    [ "create", "classsates_1_1algorithm_1_1infogen__manager.html#a3ae2a9ce4322581fded91591fbb7b838", null ],
    [ "register_or_replace_infogen", "classsates_1_1algorithm_1_1infogen__manager.html#a0282ba118914d2eeead7a5c0b5f8f8c4", null ],
    [ "run", "classsates_1_1algorithm_1_1infogen__manager.html#a6560a915076a61590777d501ece60574", null ]
];