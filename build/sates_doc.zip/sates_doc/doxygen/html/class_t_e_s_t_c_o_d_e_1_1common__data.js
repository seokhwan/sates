var class_t_e_s_t_c_o_d_e_1_1common__data =
[
    [ "DEFAULT_PATH", "group___t_e_s_t_c_o_d_e.html#ga139050dc032ada2731e75a7b301fe6a2", null ]
];