var classsates_1_1core_1_1setter_1_1double__setter =
[
    [ "set", "classsates_1_1core_1_1setter_1_1double__setter.html#a4635c5c7038a037ffc10b45da1a9db7c", null ]
];