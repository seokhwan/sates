var classsates_1_1algorithm_1_1infogen =
[
    [ "gen", "classsates_1_1algorithm_1_1infogen.html#a418898aad5bdb78a6a798b3613f34777", null ],
    [ "doc_type", "classsates_1_1algorithm_1_1infogen.html#a700a4fbe5a169c10bd72f92a7baddeac", null ],
    [ "info_name", "classsates_1_1algorithm_1_1infogen.html#a943fbc6d9470f8eb7340c540f204d243", null ]
];