var classsates_1_1core_1_1os__setting =
[
    [ "OS", "classsates_1_1core_1_1os__setting.html#a95928f9e59edf000b94af1678c4d94ac", null ],
    [ "DIR_SEPARATOR", "classsates_1_1core_1_1os__setting.html#a7b29c7afbba29556c4557079cd1a3ac4", null ]
];