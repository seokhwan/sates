var classsates_1_1util_1_1string__transfer =
[
    [ "receive", "group__util.html#ga937918c51b42965f3b39813b073a6963", null ],
    [ "send", "group__util.html#ga13b7f7db5f766110f3710bd8732d7a66", null ]
];