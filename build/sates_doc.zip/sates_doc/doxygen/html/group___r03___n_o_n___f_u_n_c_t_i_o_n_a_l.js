var group___r03___n_o_n___f_u_n_c_t_i_o_n_a_l =
[
    [ "RNF_0001_VARIOUS_INPUT_OUTPUT", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r03___n_o_n___f_u_n_c_t_i_o_n_a_l_1_1_r_n_f__0001___66bd930129142fdef3f2332eaeef7749.html", null ],
    [ "RNF_0002_ALGORITHM_EXTENSION", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r03___n_o_n___f_u_n_c_t_i_o_n_a_l_1_1_r_n_f__0002___5f589569d4f05a08e2f4144bd92449fe.html", null ]
];