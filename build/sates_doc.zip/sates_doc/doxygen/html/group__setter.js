var group__setter =
[
    [ "double_setter", "classsates_1_1core_1_1setter_1_1double__setter.html", [
      [ "set", "classsates_1_1core_1_1setter_1_1double__setter.html#a4635c5c7038a037ffc10b45da1a9db7c", null ]
    ] ],
    [ "guess", "classsates_1_1core_1_1setter_1_1guess.html", [
      [ "what", "classsates_1_1core_1_1setter_1_1guess.html#a2f54b3435c8db0f47b78f827f246cd0a", null ]
    ] ],
    [ "long_setter", "classsates_1_1core_1_1setter_1_1long__setter.html", [
      [ "set", "classsates_1_1core_1_1setter_1_1long__setter.html#a290cfb2fbb5fbf557181e111d845fc9e", null ]
    ] ],
    [ "mul_line_str_setter", "classsates_1_1core_1_1setter_1_1mul__line__str__setter.html", [
      [ "set", "classsates_1_1core_1_1setter_1_1mul__line__str__setter.html#a9d9b4fb772b0e49ceacd8dbbac7e3c05", null ]
    ] ],
    [ "setter", "classsates_1_1core_1_1setter_1_1setter.html", [
      [ "set", "classsates_1_1core_1_1setter_1_1setter.html#a22b11b6670ffa463118de9d4e3615109", null ]
    ] ],
    [ "setter_manager", "classsates_1_1core_1_1setter_1_1setter__manager.html", [
      [ "set", "classsates_1_1core_1_1setter_1_1setter__manager.html#ab81576240889ed7bf483270c12923f58", null ],
      [ "create", "classsates_1_1core_1_1setter_1_1setter__manager.html#ab721e218fa541f9e33e6bdff709a26d4", null ],
      [ "register_setter", "classsates_1_1core_1_1setter_1_1setter__manager.html#a96fa95f582b441abb90e05c16e2e7209", null ]
    ] ],
    [ "single_line_str_setter", "classsates_1_1core_1_1setter_1_1single__line__str__setter.html", [
      [ "set", "classsates_1_1core_1_1setter_1_1single__line__str__setter.html#a9b633479e212f006fa5c03c8bac75bea", null ]
    ] ]
];