var classsates_1_1input_1_1sates__doc_1_1item__data =
[
    [ "item_data", "classsates_1_1input_1_1sates__doc_1_1item__data.html#af12a8ab0e611cc32c9c6d6173fc8c058", null ],
    [ "name", "classsates_1_1input_1_1sates__doc_1_1item__data.html#af9a814b31c95aa7354eb483186014a1b", null ],
    [ "data", "classsates_1_1input_1_1sates__doc_1_1item__data.html#aa123acc551aa842cfea6173e9ff411e8", null ]
];