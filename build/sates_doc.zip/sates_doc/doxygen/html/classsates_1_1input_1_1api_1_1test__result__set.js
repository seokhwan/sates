var classsates_1_1input_1_1api_1_1test__result__set =
[
    [ "set", "classsates_1_1input_1_1api_1_1test__result__set.html#a28e89e96c9b2971bef906f5d9140a528", null ],
    [ "call", "classsates_1_1input_1_1api_1_1test__result__set.html#abe68ca810d63ec17e979d4f2b8d3b2f4", null ]
];