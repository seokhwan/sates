var classsates_1_1core_1_1doc__spec =
[
    [ "doc_spec", "classsates_1_1core_1_1doc__spec.html#a908e75a633d3316484b7f3f3c0162d92", null ],
    [ "no_duplicate_add", "classsates_1_1core_1_1doc__spec.html#a5ff1c5da72454be5723dec8e9beaa541", null ],
    [ "resolve_help", "classsates_1_1core_1_1doc__spec.html#a47dcccbb78455e3214ebb969c70a65f5", null ],
    [ "resolve_help", "classsates_1_1core_1_1doc__spec.html#aa2089c206f6c9e63cb36c7d8a1ceedf1", null ],
    [ "cross_ref_gen1", "classsates_1_1core_1_1doc__spec.html#ace7ec05404354c66b6ff53cd9e900d75", null ],
    [ "cross_ref_gen2", "classsates_1_1core_1_1doc__spec.html#a3ee5a467cec9db1efb3594c32b890405", null ],
    [ "parents", "classsates_1_1core_1_1doc__spec.html#a53aea404529f8a29e623fbd62c5b79ea", null ],
    [ "children", "classsates_1_1core_1_1doc__spec.html#a392113845776035aa798ec5adce9485a", null ],
    [ "test_cases", "classsates_1_1core_1_1doc__spec.html#a6a04f9043cbad6b7060ec6ee6110e018", null ]
];