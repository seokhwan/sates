var classsates_1_1test_1_1cs_1_1api__caller =
[
    [ "connect", "classsates_1_1test_1_1cs_1_1api__caller.html#ab9ddc10b863eb293c3be67a5155db1fe", null ],
    [ "call", "classsates_1_1test_1_1cs_1_1api__caller.html#afd248326609e0db8469e543bc62ed100", null ]
];