var group__core =
[
    [ "setter", "group__setter.html", "group__setter" ],
    [ "doc", "classsates_1_1core_1_1doc.html", [
      [ "doc", "classsates_1_1core_1_1doc.html#a775145a769c58de44fd0ade4aa0a07d1", null ],
      [ "get_info", "classsates_1_1core_1_1doc.html#a449af4d14cee2fc81bede53cbd1718d7", null ],
      [ "set_info", "classsates_1_1core_1_1doc.html#abbd5504cf2a36817132211666d4a88c6", null ],
      [ "set_info", "classsates_1_1core_1_1doc.html#a05f27fc1472fdb44a49d19e0db6570e3", null ],
      [ "set_info", "classsates_1_1core_1_1doc.html#ac200a3068b0d913ad3a3742f1c8a26c5", null ],
      [ "set_info", "classsates_1_1core_1_1doc.html#a735a7b6ee9eccfe572e5edbd874a37dd", null ],
      [ "set_info", "classsates_1_1core_1_1doc.html#aec3677479f5c2e12cab1f802381b5436", null ],
      [ "add_info", "classsates_1_1core_1_1doc.html#a6bf8e00ddb2f5055bb9294b7b9b9070f", null ],
      [ "doc_type", "classsates_1_1core_1_1doc.html#a96e86b33e7528b436b39ce967691593d", null ],
      [ "uniq_id", "classsates_1_1core_1_1doc.html#a87f282d07a00927258059e42d00efe20", null ],
      [ "category_info", "classsates_1_1core_1_1doc.html#a347dbe929dd0984a0379fe7ef1683604", null ]
    ] ],
    [ "doc_factory", "classsates_1_1core_1_1doc__factory.html", [
      [ "create", "classsates_1_1core_1_1doc__factory.html#a09d31b0b22b279f84c3dacd7604d5a0a", null ]
    ] ],
    [ "doc_list", "classsates_1_1core_1_1doc__list.html", [
      [ "add", "classsates_1_1core_1_1doc__list.html#a8d833448ae3dda81fd642795b0b85584", null ],
      [ "remove", "classsates_1_1core_1_1doc__list.html#a1ab1d174eb03df9c77df328536526382", null ],
      [ "remove", "classsates_1_1core_1_1doc__list.html#a78794efa7921b6d7e2144fc70d2ec5b8", null ],
      [ "get", "classsates_1_1core_1_1doc__list.html#a6e9f77a6254c5aff9f8f5723663ac8ce", null ],
      [ "get_list", "classsates_1_1core_1_1doc__list.html#ae87482e53ff587e76641ceee0bd83c77", null ]
    ] ],
    [ "info", "classsates_1_1core_1_1info.html", [
      [ "info", "classsates_1_1core_1_1info.html#adde949ce8ca0805812e4023a188b2b57", null ],
      [ "set", "classsates_1_1core_1_1info.html#aad0744aa9c7baf18d01dd7ae8ed5dcec", null ],
      [ "set", "classsates_1_1core_1_1info.html#ae06449c85c372429396832a36288da5a", null ],
      [ "set", "classsates_1_1core_1_1info.html#af6819e5f6d252b06620e484d3f9113dd", null ],
      [ "set", "classsates_1_1core_1_1info.html#a0fc1c869ec0e7158dab62f399dc7f714", null ],
      [ "set", "classsates_1_1core_1_1info.html#a8eb1372c7e68a7202081d79f4b0fe563", null ],
      [ "get", "classsates_1_1core_1_1info.html#a20fc2e71eddc2d3167ffa87792c765e8", null ],
      [ "get", "classsates_1_1core_1_1info.html#a1ef3a88605a82a1e1d6feab48f682759", null ],
      [ "get", "classsates_1_1core_1_1info.html#acd14536a7d34d567b9156710069b909d", null ],
      [ "get", "classsates_1_1core_1_1info.html#ad0249cffaaab6f8eeb8ea2fb7bb1d3e9", null ],
      [ "info_type", "classsates_1_1core_1_1info.html#a923c477935b0d5f3e9da44bc8d637b26", null ],
      [ "name", "classsates_1_1core_1_1info.html#ad4127c960a5dddf165d07cd373ac2432", null ]
    ] ],
    [ "os_setting", "classsates_1_1core_1_1os__setting.html", [
      [ "OS", "classsates_1_1core_1_1os__setting.html#a95928f9e59edf000b94af1678c4d94ac", null ],
      [ "DIR_SEPARATOR", "classsates_1_1core_1_1os__setting.html#a7b29c7afbba29556c4557079cd1a3ac4", null ]
    ] ]
];