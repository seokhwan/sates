var classsates_1_1input_1_1api__cmd__server__json__tcpip =
[
    [ "open", "classsates_1_1input_1_1api__cmd__server__json__tcpip.html#af8dc0866c5f6d2b93ee0f1289afcbd6d", null ],
    [ "run", "classsates_1_1input_1_1api__cmd__server__json__tcpip.html#a9cbe2e26409b3937f789a8c933f9f96e", null ],
    [ "close", "classsates_1_1input_1_1api__cmd__server__json__tcpip.html#a45fa59b1942ba1bf637177f3efda8845", null ]
];