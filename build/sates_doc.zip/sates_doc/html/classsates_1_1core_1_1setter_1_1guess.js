var classsates_1_1core_1_1setter_1_1guess =
[
    [ "what", "classsates_1_1core_1_1setter_1_1guess.html#a2f54b3435c8db0f47b78f827f246cd0a", null ]
];