var classsates_1_1output_1_1custom_1_1custom__info__writer__manager =
[
    [ "create", "classsates_1_1output_1_1custom_1_1custom__info__writer__manager.html#ad303f98dfa218d3e7136dad612259f84", null ],
    [ "register_or_replace_custom_writer", "classsates_1_1output_1_1custom_1_1custom__info__writer__manager.html#af1412a0b7f1bbf1b85d09f5693a809d3", null ],
    [ "get_writer", "classsates_1_1output_1_1custom_1_1custom__info__writer__manager.html#ac1c9453f4edaa2ff6dcb4dc3de03611d", null ]
];