var namespacesates =
[
    [ "algorithm", "namespacesates_1_1algorithm.html", "namespacesates_1_1algorithm" ],
    [ "core", "namespacesates_1_1core.html", "namespacesates_1_1core" ],
    [ "input", "namespacesates_1_1input.html", "namespacesates_1_1input" ],
    [ "output", "namespacesates_1_1output.html", "namespacesates_1_1output" ],
    [ "test", "namespacesates_1_1test.html", "namespacesates_1_1test" ],
    [ "util", "namespacesates_1_1util.html", "namespacesates_1_1util" ]
];