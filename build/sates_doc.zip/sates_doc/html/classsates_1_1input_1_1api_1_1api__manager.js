var classsates_1_1input_1_1api_1_1api__manager =
[
    [ "create", "classsates_1_1input_1_1api_1_1api__manager.html#ae678d9cbcc12a565fcede250f4b82cf5", null ],
    [ "call", "classsates_1_1input_1_1api_1_1api__manager.html#a4adc89758b73090bcf38a1212f2895a0", null ]
];