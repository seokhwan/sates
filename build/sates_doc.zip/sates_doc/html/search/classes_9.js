var searchData=
[
  ['os_5fsetting',['os_setting',['../classsates_1_1core_1_1os__setting.html',1,'sates::core']]]
];
