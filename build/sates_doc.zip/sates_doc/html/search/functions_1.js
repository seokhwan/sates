var searchData=
[
  ['open',['open',['../classsates_1_1input_1_1api__cmd__server__json__tcpip.html#af8dc0866c5f6d2b93ee0f1289afcbd6d',1,'sates::input::api_cmd_server_json_tcpip']]]
];
