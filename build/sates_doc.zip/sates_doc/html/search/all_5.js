var searchData=
[
  ['guess',['guess',['../classsates_1_1core_1_1setter_1_1guess.html',1,'sates::core::setter']]]
];
