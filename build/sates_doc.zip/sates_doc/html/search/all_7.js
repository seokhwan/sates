var searchData=
[
  ['long_5fsetter',['long_setter',['../classsates_1_1core_1_1setter_1_1long__setter.html',1,'sates::core::setter']]]
];
