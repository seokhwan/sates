var class_t_e_s_t_c_o_d_e_1_1_t01___u_n_i_t_1_1_t_u__00001___s_t_r_i_n_g___t_r_a_n_s_f_e_r =
[
    [ "init", "group___t01___u_n_i_t.html#ga4efced00675a6925eef6e4bf123bc5b7", null ],
    [ "run", "group___t01___u_n_i_t.html#ga25762fc1f5f535bc4c1560f93be1706c", null ],
    [ "terminate", "group___t01___u_n_i_t.html#gadbd4fe1353b2bbb232848919bea6994e", null ]
];