var classsates_1_1input_1_1api__cmd__server =
[
    [ "open", "group__input.html#ga0577cb4feefe3f9a43220c4836ad76f3", null ],
    [ "run", "group__input.html#gaf7921babc422322c2bdd3212b7de44d1", null ],
    [ "close", "group__input.html#ga09ed1a44588e43a1fe01d05ae74eb636", null ]
];