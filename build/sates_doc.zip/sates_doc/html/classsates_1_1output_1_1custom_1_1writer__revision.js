var classsates_1_1output_1_1custom_1_1writer__revision =
[
    [ "writer_revision", "classsates_1_1output_1_1custom_1_1writer__revision.html#a8ba91a99989b3da7bcc548cafa9d3b98", null ],
    [ "write", "classsates_1_1output_1_1custom_1_1writer__revision.html#af9d09c0391b87c347948d4c2c1ae3336", null ]
];