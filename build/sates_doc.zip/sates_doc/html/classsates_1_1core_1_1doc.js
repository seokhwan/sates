var classsates_1_1core_1_1doc =
[
    [ "doc", "classsates_1_1core_1_1doc.html#a775145a769c58de44fd0ade4aa0a07d1", null ],
    [ "get_info", "classsates_1_1core_1_1doc.html#a449af4d14cee2fc81bede53cbd1718d7", null ],
    [ "set_info", "classsates_1_1core_1_1doc.html#abbd5504cf2a36817132211666d4a88c6", null ],
    [ "set_info", "classsates_1_1core_1_1doc.html#a05f27fc1472fdb44a49d19e0db6570e3", null ],
    [ "set_info", "classsates_1_1core_1_1doc.html#ac200a3068b0d913ad3a3742f1c8a26c5", null ],
    [ "set_info", "classsates_1_1core_1_1doc.html#a735a7b6ee9eccfe572e5edbd874a37dd", null ],
    [ "set_info", "classsates_1_1core_1_1doc.html#aec3677479f5c2e12cab1f802381b5436", null ],
    [ "add_info", "classsates_1_1core_1_1doc.html#a6bf8e00ddb2f5055bb9294b7b9b9070f", null ],
    [ "doc_type", "classsates_1_1core_1_1doc.html#a96e86b33e7528b436b39ce967691593d", null ],
    [ "uniq_id", "classsates_1_1core_1_1doc.html#a87f282d07a00927258059e42d00efe20", null ],
    [ "category_info", "classsates_1_1core_1_1doc.html#a347dbe929dd0984a0379fe7ef1683604", null ]
];