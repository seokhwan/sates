var group___t01___a_c_c_e_p_t_a_n_c_e =
[
    [ "TA_0001_ACCEPTANCE", "class_d_o_c_1_1_t_e_s_t_c_a_s_e_1_1_t01___a_c_c_e_p_t_a_n_c_e_1_1_t_a__0001___a_c_c_e_p_t_a_n_c_e.html", null ]
];