var classsates_1_1input_1_1api_1_1doc__add =
[
    [ "set", "classsates_1_1input_1_1api_1_1doc__add.html#a21a33418784e03bda6551e476ba79938", null ],
    [ "set", "classsates_1_1input_1_1api_1_1doc__add.html#abcd345c292531dbd5c674f8041ca2452", null ]
];