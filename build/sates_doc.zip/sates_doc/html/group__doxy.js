var group__doxy =
[
    [ "doxyrun_gen_common", "classsates_1_1output_1_1doxy_1_1doxyrun__gen__common.html", [
      [ "doxyfilegen", "classsates_1_1output_1_1doxy_1_1doxyrun__gen__common.html#a74b308fab63ef31fd1d326a5aff1173e", null ]
    ] ],
    [ "doxyrun_gen_ubuntu", "classsates_1_1output_1_1doxy_1_1doxyrun__gen__ubuntu.html", [
      [ "generate", "classsates_1_1output_1_1doxy_1_1doxyrun__gen__ubuntu.html#ac6019a02b9b1c6355b6a5e045fa8f8d3", null ]
    ] ],
    [ "doxyrun_gen_win", "classsates_1_1output_1_1doxy_1_1doxyrun__gen__win.html", [
      [ "generate", "classsates_1_1output_1_1doxy_1_1doxyrun__gen__win.html#a036cf9c60e1ca92436f78ad2ba15dca5", null ]
    ] ]
];