var namespace_d_o_c =
[
    [ "SPEC", "namespace_d_o_c_1_1_s_p_e_c.html", "namespace_d_o_c_1_1_s_p_e_c" ],
    [ "TESTCASE", "namespace_d_o_c_1_1_t_e_s_t_c_a_s_e.html", "namespace_d_o_c_1_1_t_e_s_t_c_a_s_e" ]
];