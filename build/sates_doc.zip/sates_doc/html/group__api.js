var group__api =
[
    [ "api_manager", "classsates_1_1input_1_1api_1_1api__manager.html", [
      [ "create", "classsates_1_1input_1_1api_1_1api__manager.html#ae678d9cbcc12a565fcede250f4b82cf5", null ],
      [ "call", "classsates_1_1input_1_1api_1_1api__manager.html#a4adc89758b73090bcf38a1212f2895a0", null ]
    ] ],
    [ "doc_add", "classsates_1_1input_1_1api_1_1doc__add.html", [
      [ "set", "classsates_1_1input_1_1api_1_1doc__add.html#a21a33418784e03bda6551e476ba79938", null ],
      [ "call", "classsates_1_1input_1_1api_1_1doc__add.html#a92b55ea5cbab797f7e1702f5440ba45b", null ]
    ] ],
    [ "generate_doc", "classsates_1_1input_1_1api_1_1generate__doc.html", [
      [ "call", "classsates_1_1input_1_1api_1_1generate__doc.html#a44ec6dcb492104a01f473139e63663b5", null ]
    ] ],
    [ "generate_doxygen", "classsates_1_1input_1_1api_1_1generate__doxygen.html", [
      [ "common_routine", "classsates_1_1input_1_1api_1_1generate__doxygen.html#aba5c88ba86d08284aa8d2492fa9244aa", null ],
      [ "set", "classsates_1_1input_1_1api_1_1generate__doxygen.html#a7c7b197e976d1fd1f1a5850f2c61d885", null ],
      [ "call", "classsates_1_1input_1_1api_1_1generate__doxygen.html#aef97b383bd4def1fd6023227f5d2ab23", null ]
    ] ],
    [ "mulstring_set", "classsates_1_1input_1_1api_1_1mulstring__set.html", [
      [ "set", "classsates_1_1input_1_1api_1_1mulstring__set.html#aa2e49a90e3f101f7e156c6ec6ed98ba4", null ],
      [ "call", "classsates_1_1input_1_1api_1_1mulstring__set.html#aa89c4350a957ac0f86ac51c44d262a13", null ]
    ] ],
    [ "read_dir", "classsates_1_1input_1_1api_1_1read__dir.html", [
      [ "set", "classsates_1_1input_1_1api_1_1read__dir.html#aa53d51534701705335889a997b37cab4", null ],
      [ "call", "classsates_1_1input_1_1api_1_1read__dir.html#a5d368ece9f9529ec6ba0a2172e1bd24e", null ]
    ] ],
    [ "source_copy_csharp", "classsates_1_1input_1_1api_1_1source__copy__csharp.html", [
      [ "call", "classsates_1_1input_1_1api_1_1source__copy__csharp.html#a21f5cdf997befa7ff315f4fcac44f7f6", null ]
    ] ],
    [ "test_result_set", "classsates_1_1input_1_1api_1_1test__result__set.html", [
      [ "set", "classsates_1_1input_1_1api_1_1test__result__set.html#a663fe172dc8027fb89d1a14a47a6f3ce", null ],
      [ "call", "classsates_1_1input_1_1api_1_1test__result__set.html#abe68ca810d63ec17e979d4f2b8d3b2f4", null ]
    ] ]
];