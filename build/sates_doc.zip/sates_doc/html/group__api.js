var group__api =
[
    [ "api_manager", "classsates_1_1input_1_1api_1_1api__manager.html", [
      [ "create", "classsates_1_1input_1_1api_1_1api__manager.html#ae678d9cbcc12a565fcede250f4b82cf5", null ],
      [ "run", "classsates_1_1input_1_1api_1_1api__manager.html#af5b668e072fda63e8d6839081bd66c58", null ]
    ] ],
    [ "doc_add", "classsates_1_1input_1_1api_1_1doc__add.html", [
      [ "set", "classsates_1_1input_1_1api_1_1doc__add.html#a21a33418784e03bda6551e476ba79938", null ],
      [ "set", "classsates_1_1input_1_1api_1_1doc__add.html#abcd345c292531dbd5c674f8041ca2452", null ]
    ] ],
    [ "mulstring_set", "classsates_1_1input_1_1api_1_1mulstring__set.html", [
      [ "set", "classsates_1_1input_1_1api_1_1mulstring__set.html#aa2e49a90e3f101f7e156c6ec6ed98ba4", null ],
      [ "set", "classsates_1_1input_1_1api_1_1mulstring__set.html#a44c7cfe4f9f9c8d86181ac22903c2333", null ]
    ] ],
    [ "test_result_set", "classsates_1_1input_1_1api_1_1test__result__set.html", [
      [ "set", "classsates_1_1input_1_1api_1_1test__result__set.html#a663fe172dc8027fb89d1a14a47a6f3ce", null ],
      [ "set", "classsates_1_1input_1_1api_1_1test__result__set.html#a7d7f8cc0bd7b3bf751f55044bfcb0429", null ]
    ] ]
];