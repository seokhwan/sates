var classsates_1_1input_1_1api_1_1test__result__set =
[
    [ "set", "classsates_1_1input_1_1api_1_1test__result__set.html#a663fe172dc8027fb89d1a14a47a6f3ce", null ],
    [ "call", "classsates_1_1input_1_1api_1_1test__result__set.html#abe68ca810d63ec17e979d4f2b8d3b2f4", null ]
];