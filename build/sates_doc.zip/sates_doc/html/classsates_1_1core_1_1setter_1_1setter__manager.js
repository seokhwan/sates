var classsates_1_1core_1_1setter_1_1setter__manager =
[
    [ "set", "classsates_1_1core_1_1setter_1_1setter__manager.html#ab81576240889ed7bf483270c12923f58", null ],
    [ "create", "classsates_1_1core_1_1setter_1_1setter__manager.html#ab721e218fa541f9e33e6bdff709a26d4", null ],
    [ "register_setter", "classsates_1_1core_1_1setter_1_1setter__manager.html#a96fa95f582b441abb90e05c16e2e7209", null ]
];