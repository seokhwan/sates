var classsates_1_1output_1_1custom_1_1custom__info__writer =
[
    [ "write", "classsates_1_1output_1_1custom_1_1custom__info__writer.html#a3ceef369a2a89f4f148463e416879897", null ],
    [ "info_name", "classsates_1_1output_1_1custom_1_1custom__info__writer.html#acb8fa855ca3185549900f5df82025735", null ]
];