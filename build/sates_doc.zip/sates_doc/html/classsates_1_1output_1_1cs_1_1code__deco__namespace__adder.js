var classsates_1_1output_1_1cs_1_1code__deco__namespace__adder =
[
    [ "add_extension", "classsates_1_1output_1_1cs_1_1code__deco__namespace__adder.html#aa4fd5fca34e12adacfd63ba7fdc18992", null ],
    [ "add_exclusion_filename_pattern", "classsates_1_1output_1_1cs_1_1code__deco__namespace__adder.html#abf8a21f3a7c4438cd2734132e995c6e4", null ],
    [ "decorate", "classsates_1_1output_1_1cs_1_1code__deco__namespace__adder.html#a31a55566c89c0decb8ae21aed8bd4f53", null ]
];