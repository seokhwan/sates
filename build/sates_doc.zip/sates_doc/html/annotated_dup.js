var annotated_dup =
[
    [ "DOC", "namespace_d_o_c.html", "namespace_d_o_c" ],
    [ "sates", "namespacesates.html", "namespacesates" ],
    [ "TESTCODE", "namespace_t_e_s_t_c_o_d_e.html", "namespace_t_e_s_t_c_o_d_e" ]
];