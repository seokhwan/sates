var namespacesates_1_1input_1_1api =
[
    [ "api_manager", "classsates_1_1input_1_1api_1_1api__manager.html", "classsates_1_1input_1_1api_1_1api__manager" ],
    [ "doc_add", "classsates_1_1input_1_1api_1_1doc__add.html", "classsates_1_1input_1_1api_1_1doc__add" ],
    [ "mulstring_set", "classsates_1_1input_1_1api_1_1mulstring__set.html", "classsates_1_1input_1_1api_1_1mulstring__set" ],
    [ "test_result_set", "classsates_1_1input_1_1api_1_1test__result__set.html", "classsates_1_1input_1_1api_1_1test__result__set" ]
];