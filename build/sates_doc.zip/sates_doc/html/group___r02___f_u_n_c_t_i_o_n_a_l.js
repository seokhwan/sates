var group___r02___f_u_n_c_t_i_o_n_a_l =
[
    [ "RF_0001_ADD_DOC", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0001___a_d_d___d_o_c.html", null ],
    [ "RF_0001_ADD_DOC_BY_TEXT_FILE", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0001___a_d_d___d_o_c___b_y___t_e_x_t___f_i_l_e.html", null ],
    [ "RF_0002_ADD_DOC_VIA_NET", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0002___a_d_d___d_o_c___v_i_a___n_e_t.html", null ],
    [ "RF_0002_DOC_GEN", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0002___d_o_c___g_e_n.html", null ],
    [ "RF_0002_SPEC_CHANGE_COST", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0002___s_p_e_c___c_h_a_n_g_e___c_o_s_t.html", null ],
    [ "RF_0003_SKIP_SEG_FAULT", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0003___s_k_i_p___s_e_g___f_a_u_l_t.html", null ],
    [ "RF_0004_READ_SATES_DOC", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0004___r_e_a_d___s_a_t_e_s___d_o_c.html", null ],
    [ "RF_0005_EDITING_TEST_LIST", "class_d_o_c_1_1_s_p_e_c_1_1_s02___s_r_s_1_1_r02___f_u_n_c_t_i_o_n_a_l_1_1_r_f__0005___e_d_i_t_i_n_g___t_e_s_t___l_i_s_t.html", null ]
];